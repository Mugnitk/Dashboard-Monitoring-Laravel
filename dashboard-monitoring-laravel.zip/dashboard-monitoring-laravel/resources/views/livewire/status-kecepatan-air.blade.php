<div>
    {{-- Success is as dangerous as failure. --}}
</div>
